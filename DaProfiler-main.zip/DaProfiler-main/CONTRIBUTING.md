No contribution allow before Daprofiler v2
